/** This component will act as the User Information Form page. */

/** CSS import */
import "./UserInfoFormPage.css";

/** React-specific import */
import { useState } from "react";

/** Custom component imports */
import HeadingLevelOne from "../components/HeadingLevelOne";
import WelcomeCard from "../components/WelcomeCard";
import FormInputElement from "../components/FormInputElement";

/**
 * This component function creates the User Information form page. That is, a page with a form for users to fill out. The data is then validated and sent to an Express server for storage in a database. This component acts as the counterpart to the UserListPage component.
 *
 * @return {JSX.Element} The full rendered User Information page.
 */
function UserInfoFormPage() {
	// Set the initial (blank) state for the form data
	const initialUserInfo = {
		firstName: "",
		lastName: "",
		email: "",
		company: "",
		role: "",
		age: 0,
	};

	// An object to store the form data
	const [userInfo, setUserInfo] = useState(initialUserInfo);

	// API POST route to use for sending the user data
	const apiPostRoute = "/api/save-user";

	/**
	 * This function updates the values for the userInfo object every time a user enters data into one of the form fields.
	 *
	 * @param {React.ChangeEvent<HTMLInputElement>} event - The React event that called this function. Specifically, it's expected that this event will be a change event on an HTML input element.
	 */
	const updateValues = (event) => {
		setUserInfo({
			...userInfo,
			[event.target.name]: event.target.value,
		});
	};

	/**
	 * This function will check the validity of the email field using the browser's native email validity mechanism. While the browser default check isn't robust, it's sufficient for this app. Specifically, this function allows for a user to finish typing in the email field and only validates once the focus moves off the email field.
	 *
	 * @param {React.FocusEvent<HTMLInputElement>} event  - The React event that called this function. Specifically, it's expected that this event will be a blur event on an HTML input element. In other words, the event should be a focus event when the focus is off the element.
	 */
	const validateEmail = (event) => {
		event.target.reportValidity();
	};

	/**
	 * This function clears the form of all inputted data.
	 *
	 */
	const clearForm = () => {
		setUserInfo(initialUserInfo);
	};

	/**
	 * This function sends the saved userInfo object representing user data to the backend server using the API route ??
	 *
	 * @param {React.SubmitEvent<HTMLButtonElement>} event - The React event that called this function. Specifically, it's expected that this event will be a click event from an HTML button or input type submit element.
	 */
	async function sendData(event) {
		// Stop the form from reloading the whole page
		event.preventDefault();

		// Check to make sure all fields have been filled out
		for (let data in userInfo) {
			if (!userInfo[data]) {
				alert("Please fill out all fields before trying to save your information...");
				return;
			}
		}

		// Check to make sure there's a proper endpoint to send to
		if (!apiPostRoute || apiPostRoute === "") {
			alert(
				"Your data could not be sent because the web developer forgot to tell me where to send it!\n\nPlease get in touch with them to resolve this issue!"
			);
		}

		let apiPostResponse = await fetch(apiPostRoute, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: JSON.stringify(userInfo),
		});

		// If the response was anything other than 200, let the user know
		if (apiPostResponse.status !== 200) {
			alert(
				`There was an error sending your data to the cloud!\n\nPlease get in touch with the developer and give them the following details:\n\nHTTP Status Code: ${apiPostResponse.status} - ${apiPostResponse.statusText}`
			);
		} else {
			alert("Your information is now in the cloud...");
			// Clear the user data since the POST request was successful
			clearForm();
		}
	}

	return (
		<>
			<HeadingLevelOne text="User Information" />
			<form className="form-container">
				<WelcomeCard wcVersion={3}>
					<FormInputElement
						inputType="text"
						inputName="firstName"
						inputPlaceholder=""
						id="firstName"
						labelText={`What should we call you\n(first name)?`}
						inputValue={userInfo.firstName}
						changeFunction={updateValues}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={2}>
					<FormInputElement
						inputType="text"
						inputName="lastName"
						inputPlaceholder=""
						id="lastName"
						labelText={`What is your family name\n(last name)?`}
						inputValue={userInfo.lastName}
						changeFunction={updateValues}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={3}>
					<FormInputElement
						inputType="email"
						inputName="email"
						inputPlaceholder=""
						id="email"
						labelText={`How can we reach you\n(email address)?`}
						required={true}
						inputValue={userInfo.email}
						changeFunction={updateValues}
						blurFunction={validateEmail}
						regexPattern="[^@\s]+@[^@\s]+\.[^@\s]{2,}"
						tooltip="Please type in a valid email complete with the @ symbol, a dot (.) and a valid domain extension (e.g., .com)"
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={2}>
					<FormInputElement
						inputType="text"
						inputName="company"
						inputPlaceholder=""
						id="company"
						labelText={`Where do you work\n(company name)?`}
						inputValue={userInfo.company}
						changeFunction={updateValues}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={3}>
					<FormInputElement
						inputType="text"
						inputName="role"
						inputPlaceholder=""
						id="role"
						labelText={
							userInfo.company
								? `What is your role at ${userInfo.company}?`
								: `What do you do for work\n(job title)?`
						}
						inputValue={userInfo.role}
						changeFunction={updateValues}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={2}>
					<FormInputElement
						inputType="number"
						inputName="age"
						inputPlaceholder=""
						id="age"
						labelText={`How many times have you been around the sun\n(age)?`}
						inputValue={userInfo.age ? userInfo.age : ""}
						changeFunction={updateValues}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={3}>
					<FormInputElement
						inputType="button"
						inputValue={"Erase what I wrote!"}
						submitFunction={clearForm}
					/>
				</WelcomeCard>
				<WelcomeCard wcVersion={3}>
					<FormInputElement
						inputType="submit"
						inputValue={"Send my info off to the cloud..."}
						submitFunction={sendData}
					/>
				</WelcomeCard>
			</form>
		</>
	);
}

export default UserInfoFormPage;

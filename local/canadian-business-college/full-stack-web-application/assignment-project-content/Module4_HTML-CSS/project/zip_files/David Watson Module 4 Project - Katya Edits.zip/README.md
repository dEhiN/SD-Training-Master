HTML

1) Added link to css/normalize.css in the <head> of all HTML pages — ensures normalize.css is loaded first to normalize browser defaults so custom styles behave predictably.
2) Applied non-breaking spaces and typographic fixes in `html/index.html` (via Typograf) to improve line breaks and typographic quality (smart spacing for short words and punctuation).
3) Attribute/tag changes applied across HTML files:
   - Added `role="navigation" aria-label="Main navigation"` to all `<nav>` elements — improves accessibility by letting assistive technologies identify the navigation region.
   - Removed an invalid `element` attribute from a `<div>` in `html/caccount.html` — eliminates invalid HTML that could break parsers or validators.
   - Added `action="#"` and `method="post"` to the create-account `<form>` in `html/caccount.html` as a placeholder for form submission behavior.
   - Added `required` attributes to `email`, `password`, `password_confirm`, and `user_fullname` inputs in `html/caccount.html` — adds client-side validation and improves UX by preventing empty submissions.
   - Added `autocomplete` attributes to form inputs in `html/login.html` and `html/caccount.html` (`email`, `current-password`/`new-password`, `name`) — enables browser autofill and a better user experience.
   - Converted task cards in `html/tasks.html` from generic `<div>` blocks into a semantic `<ul>` of `<li>` where each task is an `<article>` with headings — improves semantics, keyboard navigation, and SR compatibility.
4) Removed per-page `<link>` tags (e.g. `index.css`, `tasks.css`, `forms.css`, `login.css`) from HTML heads — HTML now loads only `normalize.css` and `main.css` because `main.css` imports the page-specific styles.
   - Reason: reduces redundancy in HTML, centralizes stylesheet loading, and makes head markup cleaner. For production builds consider concatenating CSS to avoid `@import` performance impact.

Recommendations (to add later):
   - Add `link rel="icon"` (favicon), `meta name="theme-color"`, `link rel="canonical"`, and Open Graph/Twitter Card meta tags to improve UX and social previews.
   - Add a skip link (`<a class="skip-link" href="#main">Skip to content</a>`) and ensure `<main id="main">` exists on each page for keyboard users.

Sources

- Official repository (copy raw file): https://raw.githubusercontent.com/necolas/normalize.css/master/normalize.css
- CDN (ready-to-use): https://cdnjs.com/libraries/normalize/ (choose a version and copy the CSS)
- Online typographer: Art Lebedev Typograf — https://www.artlebedev.ru/typograf/
   - Purpose: a quick online tool to post-process English (and other) text to apply typographic corrections such as smart quotes, en/em dashes, ellipses, and non-breaking spaces. Useful for projects without a build pipeline.

CSS

1) Added css/normalize.css — normalizes browser default styles (headings, margins, form elements, etc.) so layouts and typography render more consistently across user agents.
2) Imported into `css/main.css` using `@import` (forms.css, index.css, tasks.css, login.css).
   - Reason: keep a single entrypoint (`main.css`) for styles so HTML only needs to load `normalize.css` and `main.css`; simplifies maintenance while preserving page-specific rules in separate files for clarity.
   - Note: `@import` is convenient for development but can affect load performance on older setups; for production consider concatenation/build step to produce a single CSS file.
3) Added a global box-sizing reset in `css/main.css`:
   ```css
   html { box-sizing: border-box }
   *, *::before, *::after { box-sizing: inherit }
   ```
   - Reason: using `border-box` simplifies sizing calculations because padding and border are included in an element's total width/height. This prevents layout surprises when adding padding/borders and makes responsive layouts easier to reason about.
4) Added a `.container` helper class in `css/main.css`:
   ```css
   .container { 
    width: 100%;
    margin-right: auto;
    margin-left: auto;
    padding-right: 20px;
    padding-left: 20px; }
   ```
   - Reason: provide a consistent centered content area with horizontal padding so text and UI do not sit flush against the viewport edges. Applied the class to `<main>` on all pages to improve readability and visual spacing.   
5) `header` / `.container` alignment:
   - I added matching horizontal padding to align `<main>` with the header when `.container` is used. Current rules applied in `css/main.css` are:
      ```css
      header { padding: 20px 40px; }
      .container { padding: 20px 40px; }
      ```
   - Reason: when headings and main content are centered with a fixed max-width, matching horizontal padding keeps visual rhythm consistent between header and page content.
6) Utility class `.gap`:
   - Purpose: a small utility to add vertical spacing after headings or other elements where you want consistent gap without reintroducing global margins. Example usage in HTML: add `class="gap"` to an `h1`, `h3` or any block to create a bottom spacing.
   - Current rule in `css/main.css`:
      ```css
      .gap { margin-bottom: 20px; }
      ```
   - Recommendation: use `.gap` for one-off spacing inside components.
7) Unused / missing class styles (short list):
   - `section-cta-div` — present in `html/index.html`; styles were removed earlier and need either a minimal rule or removal from HTML.
   - `section-cta` — present in `html/index.html`; verify and add styles or remove.
   - `section-cta-question` — present in `html/index.html`; verify and add styles or remove.
   - `task-list` — present in `html/tasks.html` but no dedicated CSS rule found; consider adding minimal layout rules or removing the class.
8) Grid & task-card notes:
   - Why grid sometimes fails: grid must be applied to the container whose direct children are the items you want in columns. In this project the `.task-grid` wrapper contains a single `<ul class="task-list">`, so applying `display: grid` to `.task-grid` makes the UL a single grid item. The correct place for the grid is the list itself (`.task-list`), so each `<li class="task-card">` becomes a grid item and forms the columns.
   - What was changed for cards:
      - Added `<article class="task-content">` inside each `.task-card` and created `.task-content { display: flex; flex-direction: column; gap: 5px; }` to scope card layout to content only.
      - Added `.task-title` on card headings so card-heading typography can be targeted separately from other headings.
   - Сonverted the grid to percentages, but you can return it to the previous form `repeat(3, minmax(200px,1fr).
9) Forms updates (сhanges applied in `css/forms.css`):
      - Removed `margin-bottom` from `.form-element` and instead used `gap: 20px` on `.form-create-account` to control vertical spacing between form rows — this keeps row spacing consistent when using flex layout.
      - Added `gap: 20px` to `.section-form` so related links and the submit button don't touch each other.
      -  Updated `.form-element` to a row-based flex layout to improve alignment:
       ```css
       .form-element {
          display: flex;
          flex-direction: row;
          gap: 5px;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          padding: 10px 20px;
       }
       ```
       - Reason: aligns labels and inputs nicely and adapts on smaller screens via `flex-wrap`.
      -  Added `:focus` to the interactive button state so keyboard users see the same visual feedback as `:hover`:
       ```css
       .create-account-btn:hover,
       .create-account-btn:focus { /* ... */ }
       ```
       - Reason: improves accessibility and visible focus when navigating with Tab.
      - These forms changes were applied to both `html/login.html` and `html/caccount.html`.
10) Removed `css/login.css`: it only contained the following rule and was merged into `css/forms.css` because it belongs with form layout styles:
   ```css
   .form-links-div {
         display: flex;
         flex-direction: column;
         align-items: center;
         gap: 10px;
   }
   ```
11) Suggestion: consider adding `css/variables.css` to centralize CSS custom properties (colors, spacing, font sizes, breakpoints). Example:
   ```css
   :root {
      --color-accent: #5C4A31;
      --color-bg: blanchedalmond;
      --gap-lg: 20px;
   }
   ```
   Then reuse with `var(--color-accent)` across styles for easier theme changes and consistency.